<!DOCTYPE html>
<html>
<?php 
include "templet.php";
?>
<body>
<div style="position:absolute;left:400px;top:100px;">
<form style = "background: #D1D1D1; width:900px; height:200px;line-height">
    </br>
    <h1 align="center">
        <?php echo "Welcome to CS143 Query System!" ?>
    </h1>
    <ul>
    <?php echo "Through this system, you can get information about Movie. Don't hesitate to add, browse, or search information!"?>
    <ul>
</form>
</div>
</body>
</html>




